import Lamp from './Lamp';

function App() {

  return (
    <>
      <div>
        <Lamp />
      </div>
    </>
  )
}

export default App
